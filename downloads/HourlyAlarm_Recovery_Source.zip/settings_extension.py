"""Editable settings extension. Original Python 3.14 bytecode is retained separately."""
import tkinter as tk
from tkinter import simpledialog, messagebox
from datetime import datetime, timedelta


def next_daily(now, hour, minute):
    candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    return candidate + timedelta(days=1) if candidate <= now else candidate


class TimeDialog(simpledialog.Dialog):
    def __init__(self, parent, initial):
        self.initial = initial
        super().__init__(parent, '시간 설정')

    def body(self, master):
        tk.Label(master, text='매일 알림을 받을 시각을 설정하세요 (24시간제)').grid(row=0, column=0, columnspan=4, pady=10)
        self.hour = tk.StringVar(value=f'{self.initial[0]:02d}')
        self.minute = tk.StringVar(value=f'{self.initial[1]:02d}')
        hour = tk.Spinbox(master, from_=0, to=23, width=5, textvariable=self.hour)
        hour.grid(row=1, column=0, padx=5)
        tk.Label(master, text='시').grid(row=1, column=1)
        tk.Spinbox(master, from_=0, to=59, width=5, textvariable=self.minute).grid(row=1, column=2, padx=5)
        tk.Label(master, text='분').grid(row=1, column=3)
        return hour

    def validate(self):
        try:
            h, m = int(self.hour.get()), int(self.minute.get())
            if not (0 <= h <= 23 and 0 <= m <= 59):
                raise ValueError
        except ValueError:
            messagebox.showerror('입력 확인', '시는 0–23, 분은 0–59로 입력하세요.', parent=self)
            return False
        self.selection = (h, m)
        return True

    def apply(self):
        self.result = self.selection


class MinuteDialog(simpledialog.Dialog):
    def __init__(self, parent, initial=None):
        self.initial = initial
        self.daily = initial if isinstance(initial, tuple) else None
        super().__init__(parent, '분 입력')

    def body(self, master):
        tk.Label(master, text='매시 몇 분에 알릴까요? (0~59)').pack(pady=(6, 4))
        value = self.initial[1] if isinstance(self.initial, tuple) else self.initial
        self.minute = tk.StringVar(value='' if value is None else str(value))
        entry = tk.Entry(master, textvariable=self.minute, width=20)
        entry.pack(padx=16, pady=4)
        # This button is immediately beneath the original minute input.
        tk.Button(master, text='시간 설정', command=self.set_time).pack(fill='x', padx=16, pady=(8, 4))
        self.status = tk.Label(master, text=self.status_text())
        self.status.pack(pady=4)
        tk.Button(master, text='매시 알림 사용', command=self.use_hourly).pack(pady=(0, 6))
        entry.bind('<KeyRelease>', self.use_hourly)
        return entry

    def status_text(self):
        return f'매일 {self.daily[0]:02d}:{self.daily[1]:02d}에 알림' if self.daily is not None else '기본: 매시 지정한 분에 알림'

    def set_time(self):
        initial = self.daily or (datetime.now().hour, int(self.minute.get()) if self.minute.get().isdigit() and 0 <= int(self.minute.get()) <= 59 else 0)
        dialog = TimeDialog(self, initial)
        if dialog.result is not None:
            self.daily = dialog.result
            self.minute.set(str(self.daily[1]))
            self.status.config(text=self.status_text())

    def use_hourly(self, event=None):
        self.daily = None
        self.status.config(text=self.status_text())

    def validate(self):
        if self.daily is not None:
            return True
        try:
            minute = int(self.minute.get())
            if not 0 <= minute <= 59:
                raise ValueError
        except ValueError:
            messagebox.showerror('입력 확인', '0–59 사이의 정수를 입력하세요.', parent=self)
            return False
        return True

    def apply(self):
        self.result = self.daily if self.daily is not None else int(self.minute.get())


def install(namespace):
    original = namespace['HourlyAlarm']

    def ask_minute(parent, initial=None):
        return MinuteDialog(parent, initial).result

    class HourlyAlarm(original):
        def __init__(self, root, selection):
            self.alarm_hour = selection[0] if isinstance(selection, tuple) else None
            super().__init__(root, selection[1] if isinstance(selection, tuple) else selection)

        def next_alarm_time(self):
            if self.alarm_hour is None:
                return super().next_alarm_time()
            return next_daily(namespace['datetime'].now(), self.alarm_hour, self.minute)

        def refresh_labels(self):
            if self.alarm_hour is None:
                return super().refresh_labels()
            rule = f'매일 {self.alarm_hour:02d}:{self.minute:02d}에 알림'
            self.lbl_rule.config(text=rule)
            self.lbl_next.config(text=f'다음 알림: {self.next_alarm_time():%m/%d %H:%M}')
            if self.tray:
                self.tray.title = rule

        def tick(self):
            if self.alarm_hour is None:
                return super().tick()
            now = namespace['datetime'].now()
            key = (now.date(), now.hour, now.minute)
            if now.hour == self.alarm_hour and now.minute == self.minute and self.last_fired != key:
                self.last_fired = key
                self.fire()
            if not self.is_hidden():
                self.refresh_labels()
            self.root.after(500, self.tick)

        def change_minute(self):
            initial = (self.alarm_hour, self.minute) if self.alarm_hour is not None else self.minute
            selection = ask_minute(self.root, initial)
            if selection is not None:
                self.alarm_hour = selection[0] if isinstance(selection, tuple) else None
                self.minute = selection[1] if isinstance(selection, tuple) else selection
                self.last_fired = None
                self.refresh_labels()

        def fire(self, test=False):
            super().fire(test=test)
            if self.alarm_hour is not None and not test and self.alert_window is not None:
                old = f'매시 {self.minute:02d}분으로 설정한 알림입니다'
                for widget in self.alert_window.winfo_children():
                    if isinstance(widget, tk.Label) and widget.cget('text') == old:
                        widget.config(text=f'매일 {self.alarm_hour:02d}:{self.minute:02d}에 설정한 알림입니다')

    namespace['ask_minute'] = ask_minute
    namespace['HourlyAlarm'] = HourlyAlarm
