"""Editable settings extension. Original Python 3.14 bytecode is retained separately."""
import tkinter as tk
from tkinter import simpledialog, messagebox
from datetime import datetime, timedelta


ICON_PNG = 'iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAFPElEQVR4nO2ba4hVVRSAvzlzx3lUjpXlFJVpYmaZYxAlFBX0gIiUit70MGj60ZMie2AP6UeBBUWURsFQVD+CqOhBpfVDU4JErSyTMh8TkzXNaI7NjOncfqx7mfs4Z5+z19n73hP4wYJ57PXa95xz9157nQb8MwWYC3QCJxd+PxqYADQXxgwBu4BeYCuwCVgLrCn87X9FAFwAvAj8CuRTykbgGeDMWiahYSLwMPIJpk06Sn4A7gIOrU1KyTgSWAIM4i/xSukHFlHnicgB9wID1C7xSukFbgIaPOdaxQzg6xSBu5bPgeO9ZlzCLcA/HpNJc1vM85c2NALPZyBRk4wCj+PhlmgG3s1AgknlNeQDc5b8RxlIylbedjEJjcA7GUhGK6+S8nZ4NgNJpJVF2uRvyEDwLuQAcFlUklGXxzRgHclWWp8Bu4HJwGzGNji+GAI2ADuQDdVFCXT6kdh6kjgIgJUkm90/KH/QHAJcB3yVUN9GlgNXAK0l/nKF5JLofxKWbNgV0AUsNc1QCe8D8yP+Nx94CTim8PsO4DvgZ+D3ksCLtAMdyJV0GjC9EN8W4HZgRYSfT4GLE8Z7PfLtEEk78CfJP5UlMQ4nATcDxyUMsJTDkUmcEDNuqUW8PUCbydhTFsbywCPWabnnaexifqhUOSj5uR2409L5flXI9eV+5FkFlE/AAmQSbDjMRUQpGW85fiKyhQbKJ6BL4fwEhY5rpip07qj8w1novpo2q0J2RwD8hS72zqIBgKuUAXys1HPFKPCWUrcs503Yz+BWyhcl9aINXSF2fdHAsQrlPHCb58RsWIB9/KPAUSDLS1vlAbLx6RdpBvqwz+PyAJijcPgBsinJCiPAewq9OQFwikJxuULHN18qdGYGyFmdLesUOr5ZHz+kiikBsgOzZZtCxzeJ9voVdDQAe4nZIYUQIA+RLBEg1R8bBgN0T/OcQsc34xQ6rQG6qukkhY5vNDE1BMC/CsUZCh3fzFTojARIQdOWcxQ6vtHEtDtASmC2RNUB64kmpp0BspGwZTZwtkLPF+ehuwW2BcBPSqePKfV88KRSbzNI1VazG8wjG6l6kyb+G0Fa17QG+tAtpV1xKvB3SFxJZVrRUE8KIz9Sn3XBVGC7It6ibC819koKQ3nkXpruKdEw5iINUmliXlZq8JKUxvLIeuJW/HZsjUOOu/c5iLfsOC0H/BajsAfZBe6PGbcauNBx4s1Ic9YvDhLPF3Kt2s8sjhg8BFzJWAX5COAJpApjcvI90jl6OrqrYjxwKXLAqil3mWRxmMOOQrKVg3uBk0LGn0/y7tBdSLdJEnJIk9MBx0kXZZixE+sqXjAobgHOrRg/D6muxjldg90xWgt+egzywMsmxx2Yv1f7qa4gxfURrSX+iDuME3HfkDmIHAMYeTDGSGVPQBNSkQ0buxI559fiujHz0SROm5CiZ5SRAaov50bgHuBb5CpZjxxDN9lmXEGnIQ5b2YhF1WgW4Q/EotRqI9QA7DTEkVT2oXjhostgcJDwbwYfrDDEkVTu0zpfZjD6DbV5YeFNQwxJ5I00znPAhwbjq/C/Eeo2+I+TL3DQt9iKNENGOekDHiB8Is5I6xz9BKzGvn0mkhbi2+VHkbX6KmQRU2y3S0t3jN+oT955/1IjsgawDSYt3Zb+Xsdzu+7VyNo+axMwgrzEVRMmY34u1HoCNqDrc0jNtUiNwPRcSEu3wf4eYCHpV5ypaAHuJrw+56KPIGxvshd4DnkHOTM0Adcg3SPDyEJplgO7bchrO8PIq7MLkbdVD3IQB/wHAwNnqxT8whwAAAAASUVORK5CYII='

def apply_window_icon(window, default=False):
    window._github_icon = tk.PhotoImage(data=ICON_PNG, master=window)
    window.iconphoto(default, window._github_icon)


def next_daily(now, hour, minute):
    candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    return candidate + timedelta(days=1) if candidate <= now else candidate


class MinuteDialog(simpledialog.Dialog):
    def __init__(self, parent, initial=None):
        self.initial = initial
        self.daily = initial if isinstance(initial, tuple) else None
        super().__init__(parent, '분 입력')

    def body(self, master):
        apply_window_icon(self)
        tk.Label(master, text='매시 몇 분에 알릴까요? (0~59)').pack(pady=(6, 4))
        value = self.initial[1] if isinstance(self.initial, tuple) else self.initial
        self.minute = tk.StringVar(value='' if value is None else str(value))
        entry = tk.Entry(master, textvariable=self.minute, width=20)
        entry.pack(padx=16, pady=4)
        # This button is immediately beneath the original minute input.
        self._button_icon = tk.PhotoImage(data=ICON_PNG, master=self).subsample(4, 4)
        tk.Button(master, text='시간 설정', image=self._button_icon, compound='left', command=self.set_time).pack(fill='x', padx=16, pady=(8, 4))
        self.time_fields = tk.Frame(master)
        initial_time = self.daily or (datetime.now().hour, 0)
        self.hour = tk.StringVar(value=f'{initial_time[0]:02d}')
        self.time_minute = tk.StringVar(value=f'{initial_time[1]:02d}')
        tk.Label(self.time_fields, text='매일 (24시간제)').pack(side='left', padx=4)
        tk.Spinbox(self.time_fields, from_=0, to=23, width=4, textvariable=self.hour).pack(side='left')
        tk.Label(self.time_fields, text='시').pack(side='left', padx=4)
        tk.Spinbox(self.time_fields, from_=0, to=59, width=4, textvariable=self.time_minute).pack(side='left')
        tk.Label(self.time_fields, text='분').pack(side='left', padx=4)
        self.status = tk.Label(master, text=self.status_text())
        self.status.pack(pady=4)
        tk.Button(master, text='매시 알림 사용', command=self.use_hourly).pack(pady=(0, 6))
        entry.bind('<KeyRelease>', self.use_hourly)
        if self.daily is not None:
            self.time_fields.pack(before=self.status, pady=8)
        return entry

    def status_text(self):
        return f'매일 {self.daily[0]:02d}:{self.daily[1]:02d}에 알림' if self.daily is not None else '기본: 매시 지정한 분에 알림'

    def set_time(self):
        if self.daily is None:
            value = self.minute.get()
            minute = int(value) if value.isdigit() and 0 <= int(value) <= 59 else 0
            self.daily = (datetime.now().hour, minute)
            self.hour.set(f'{self.daily[0]:02d}')
            self.time_minute.set(f'{minute:02d}')
        self.time_fields.pack(before=self.status, pady=8)
        self.status.config(text='시·분을 지정한 뒤 확인을 누르세요')
        self.update_idletasks()

    def use_hourly(self, event=None):
        self.daily = None
        self.time_fields.pack_forget()
        self.status.config(text=self.status_text())

    def validate(self):
        if self.daily is not None:
            try:
                hour, minute = int(self.hour.get()), int(self.time_minute.get())
                if not (0 <= hour <= 23 and 0 <= minute <= 59):
                    raise ValueError
            except ValueError:
                messagebox.showerror('입력 확인', '시는 0–23, 분은 0–59로 입력하세요.', parent=self)
                return False
            self.daily = (hour, minute)
            return True
        try:
            minute = int(self.minute.get())
            if not 0 <= minute <= 59:
                raise ValueError
        except ValueError:
            messagebox.showerror('입력 확인', '0–59 사이의 정수를 입력하세요.', parent=self)
            return False
        return True

    def apply(self):
        self.result = self.daily if self.daily is not None else int(self.minute.get())


def install(namespace):
    original = namespace['HourlyAlarm']

    def ask_minute(parent, initial=None):
        return MinuteDialog(parent, initial).result

    class HourlyAlarm(original):
        def __init__(self, root, selection):
            apply_window_icon(root, default=True)
            self.alarm_hour = selection[0] if isinstance(selection, tuple) else None
            super().__init__(root, selection[1] if isinstance(selection, tuple) else selection)

        def quit(self):
            # The main-window Exit button keeps the tray and scheduler alive.
            self.hide()

        def exit_program(self):
            # A distinct tray-menu action still permits a complete shutdown.
            super().quit()

        def start_tray(self):
            pystray = namespace['pystray']
            menu = pystray.Menu(
                pystray.MenuItem('열기', lambda: self.root.after(0, self.show), default=True),
                pystray.MenuItem('완전히 종료', lambda: self.root.after(0, self.exit_program)),
            )
            self.tray = pystray.Icon('hourly_alarm', namespace['make_tray_image'](), '매시 알림', menu)
            self.tray.run_detached()

        def next_alarm_time(self):
            if self.alarm_hour is None:
                return super().next_alarm_time()
            return next_daily(namespace['datetime'].now(), self.alarm_hour, self.minute)

        def refresh_labels(self):
            if self.alarm_hour is None:
                return super().refresh_labels()
            rule = f'매일 {self.alarm_hour:02d}:{self.minute:02d}에 알림'
            self.lbl_rule.config(text=rule)
            self.lbl_next.config(text=f'다음 알림: {self.next_alarm_time():%m/%d %H:%M}')
            if self.tray:
                self.tray.title = rule

        def tick(self):
            if self.alarm_hour is None:
                return super().tick()
            now = namespace['datetime'].now()
            key = (now.date(), now.hour, now.minute)
            if now.hour == self.alarm_hour and now.minute == self.minute and self.last_fired != key:
                self.last_fired = key
                self.fire()
            if not self.is_hidden():
                self.refresh_labels()
            self.root.after(500, self.tick)

        def change_minute(self):
            initial = (self.alarm_hour, self.minute) if self.alarm_hour is not None else self.minute
            selection = ask_minute(self.root, initial)
            if selection is not None:
                self.alarm_hour = selection[0] if isinstance(selection, tuple) else None
                self.minute = selection[1] if isinstance(selection, tuple) else selection
                self.last_fired = None
                self.refresh_labels()

        def fire(self, test=False):
            super().fire(test=test)
            if self.alarm_hour is not None and not test and self.alert_window is not None:
                old = f'매시 {self.minute:02d}분으로 설정한 알림입니다'
                for widget in self.alert_window.winfo_children():
                    if isinstance(widget, tk.Label) and widget.cget('text') == old:
                        widget.config(text=f'매일 {self.alarm_hour:02d}:{self.minute:02d}에 설정한 알림입니다')

    if namespace.get('HAS_TRAY'):
        def make_tray_image():
            from io import BytesIO
            import base64
            return namespace['Image'].open(BytesIO(base64.b64decode(ICON_PNG))).convert('RGBA')
        namespace['make_tray_image'] = make_tray_image
    namespace['ask_minute'] = ask_minute
    namespace['HourlyAlarm'] = HourlyAlarm
