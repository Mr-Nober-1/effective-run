"""Repack the original unsigned PyInstaller executable with the settings extension.
Run with Python 3.14. No Windows bootloader or dependencies are replaced.
"""
from pathlib import Path
import base64
import hashlib
import marshal
import struct
import sys
import zlib

ROOT = Path(__file__).resolve().parent
MAGIC = b'MEI\014\013\012\013\016'
EXPECTED_ORIGINAL_SHA256 = '8ec822ec9a887704bf8d599b302d16480759ecd2bc7c1a61bd393aeb338a6e6c'


def read_archive(data):
    cookie = data.rfind(MAGIC)
    if cookie < 0:
        raise ValueError('PyInstaller archive not found')
    magic, size, offset, length, version, lib = struct.unpack('!8sIIII64s', data[cookie:cookie + 88])
    base = cookie + 88 - size
    pos, end = base + offset, base + offset + length
    entries = []
    while pos < end:
        n, off, compressed, unpacked, flag, kind = struct.unpack('!IIIIBc', data[pos:pos + 18])
        name_field = data[pos + 18:pos + n]
        name = name_field.rstrip(b'\0').decode()
        entries.append((name, data[base + off:base + off + compressed], unpacked, flag, kind, name_field))
        pos += n
    if pos != end or version != 314:
        raise ValueError('Unexpected archive format or Python version')
    return base, lib, entries


def create_entrypoint():
    original = (ROOT / 'hourly_alarm.marshal').read_bytes()
    extension = (ROOT / 'settings_extension.py').read_text(encoding='utf-8')
    return "import marshal, base64\n" + "_original = {'__name__': 'hourly_alarm_original'}\n" + f"exec(marshal.loads(base64.b64decode({base64.b64encode(original)!r})), _original)\n" + extension + "\ninstall(_original)\nif __name__ == '__main__':\n    _original['main']()\n"


def build(source, destination):
    if sys.version_info[:2] != (3, 14):
        raise RuntimeError('Use Python 3.14 to preserve compatibility with embedded runtime')
    data = Path(source).read_bytes()
    if hashlib.sha256(data).hexdigest() != EXPECTED_ORIGINAL_SHA256:
        raise ValueError('Original EXE checksum mismatch')
    # Reject signed files rather than silently breaking an existing signature.
    pe = struct.unpack_from('<I', data, 0x3c)[0]
    optional = pe + 24
    directory = optional + (112 if struct.unpack_from('<H', data, optional)[0] == 0x20b else 96)
    cert_offset, cert_size = struct.unpack_from('<II', data, directory + 8 * 4)
    if cert_offset or cert_size:
        raise ValueError('Signed EXE requires a separate signing workflow')
    base, lib, entries = read_archive(data)
    source_text = create_entrypoint()
    (ROOT / 'hourly_alarm.py').write_text(source_text, encoding='utf-8')
    replacement = marshal.dumps(compile(source_text, 'hourly_alarm.py', 'exec'))
    payloads = bytearray()
    toc = bytearray()
    replaced = 0
    for name, payload, unpacked, flag, kind, name_field in entries:
        if name == 'hourly_alarm' and kind == b's':
            payload = zlib.compress(replacement, 9) if flag else replacement
            unpacked = len(replacement)
            replaced += 1
        toc.extend(struct.pack('!IIIIBc', 18 + len(name_field), len(payloads), len(payload), unpacked, flag, kind))
        toc.extend(name_field)
        payloads.extend(payload)
    if replaced != 1:
        raise ValueError('Expected exactly one application entrypoint')
    cookie = struct.pack('!8sIIII64s', MAGIC, len(payloads) + len(toc) + 88, len(payloads), len(toc), 314, lib)
    result = data[:base] + payloads + toc + cookie
    # Maintain the PE image checksum. The bundled PE bootloader and DLLs are preserved.
    checksum_offset = optional + 64
    result = bytearray(result)
    struct.pack_into('<I', result, checksum_offset, 0)
    padded = result if len(result) % 2 == 0 else result + b'\0'
    checksum = 0
    for (word,) in struct.iter_unpack('<H', padded):
        checksum += word
        checksum = (checksum & 0xffff) + (checksum >> 16)
    checksum = (checksum & 0xffff) + (checksum >> 16)
    struct.pack_into('<I', result, checksum_offset, checksum + len(result))
    Path(destination).write_bytes(result)
    print('Created', destination, 'SHA256', hashlib.sha256(result).hexdigest())


if __name__ == '__main__':
    build(sys.argv[1], sys.argv[2])
