import base64
from datetime import datetime
import importlib.util
import marshal
from pathlib import Path
import unittest
from unittest.mock import patch, Mock
import zlib

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('alarm', ROOT / 'hourly_alarm.py')
alarm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(alarm)
ns = alarm._original
App = ns['HourlyAlarm']


class ScheduleTests(unittest.TestCase):
    def test_daily_future(self):
        self.assertEqual(alarm.next_daily(datetime(2026, 10, 10, 9), 10, 30), datetime(2026, 10, 10, 10, 30))

    def test_daily_next_day(self):
        self.assertEqual(alarm.next_daily(datetime(2026, 10, 10, 23, 59), 0, 0), datetime(2026, 10, 11))

    def test_daily_equal_time(self):
        self.assertEqual(alarm.next_daily(datetime(2026, 10, 10, 10, 30), 10, 30), datetime(2026, 10, 11, 10, 30))

    def test_leap_year(self):
        self.assertEqual(alarm.next_daily(datetime(2028, 2, 28, 23), 1, 0), datetime(2028, 2, 29, 1))

    def test_daily_tick_once_per_minute(self):
        app = App.__new__(App)
        app.alarm_hour, app.minute, app.last_fired = 10, 30, None
        app.root = Mock()
        clock = Mock()
        clock.now.return_value = datetime(2026, 10, 10, 10, 30, 5)
        with patch.dict(ns, datetime=clock), patch.object(App, 'fire') as fire, patch.object(App, 'is_hidden', return_value=True):
            app.tick()
            app.tick()
            self.assertEqual(fire.call_count, 1)
            clock.now.return_value = datetime(2026, 10, 10, 11, 30)
            app.tick()
            self.assertEqual(fire.call_count, 1)
            clock.now.return_value = datetime(2026, 10, 11, 10, 30)
            app.tick()
            self.assertEqual(fire.call_count, 2)

    def test_hourly_original_delegation(self):
        app = App.__new__(App)
        app.alarm_hour, app.minute = None, 15
        base = App.__mro__[1]
        with patch.object(base, 'tick') as tick:
            app.tick()
            tick.assert_called_once()

    def test_default_settings(self):
        self.assertEqual(App.AUTO_CLOSE_SEC, 60)
        self.assertEqual(App.MESSAGE, '설정한 알림 시간입니다')


class UITests(unittest.TestCase):
    def setUp(self):
        self.root = alarm.tk.Tk()
        self.root.withdraw()

    def tearDown(self):
        for timer in self.root.tk.call('after', 'info'):
            self.root.after_cancel(timer)
        self.root.destroy()

    def automate_dialog(self, callback):
        def run():
            dialogs = [w for w in self.root.winfo_children() if isinstance(w, alarm.tk.Toplevel)]
            self.assertTrue(dialogs)
            callback(dialogs[-1])
        self.root.after(100, run)

    def test_button_below_entry_and_hourly_zero(self):
        def fill(dialog):
            body = dialog.initial_focus.master
            widgets = body.pack_slaves()
            entry_index = widgets.index(dialog.initial_focus)
            self.assertEqual(widgets[entry_index + 1].cget('text'), '시간 설정')
            dialog.minute.set('0')
            dialog.ok()
        self.automate_dialog(fill)
        self.assertEqual(alarm.MinuteDialog(self.root).result, 0)

    def test_cancel(self):
        self.automate_dialog(lambda d: d.cancel())
        self.assertIsNone(alarm.MinuteDialog(self.root, 15).result)

    def test_daily_selection_and_cancel_preserves_initial(self):
        initial = (9, 15)
        self.automate_dialog(lambda d: d.cancel())
        self.assertIsNone(alarm.MinuteDialog(self.root, initial).result)
        self.automate_dialog(lambda d: d.ok())
        self.assertEqual(alarm.MinuteDialog(self.root, initial).result, initial)

    def test_invalid_minutes(self):
        def check(dialog):
            with patch.object(alarm.messagebox, 'showerror') as error:
                for value in ['-1', '60', '', 'abc']:
                    dialog.minute.set(value)
                    self.assertFalse(dialog.validate())
                self.assertEqual(error.call_count, 4)
            dialog.minute.set('59')
            dialog.ok()
        self.automate_dialog(check)
        self.assertEqual(alarm.MinuteDialog(self.root).result, 59)

    def test_time_validation(self):
        def check(dialog):
            dialog.set_time()
            with patch.object(alarm.messagebox, 'showerror'):
                for h, m in [('24', '0'), ('-1', '0'), ('0', '60'), ('x', '1')]:
                    dialog.hour.set(h)
                    dialog.time_minute.set(m)
                    self.assertFalse(dialog.validate())
            dialog.hour.set('23')
            dialog.time_minute.set('59')
            dialog.ok()
        self.automate_dialog(check)
        self.assertEqual(alarm.MinuteDialog(self.root).result, (23, 59))

    def test_inline_time_one_window_one_confirmation(self):
        def choose(dialog):
            dialog.set_time()
            dialog.hour.set('8')
            dialog.time_minute.set('25')
            self.assertTrue(dialog.time_fields.winfo_manager())
            self.assertFalse(any(isinstance(w, alarm.tk.Toplevel) for w in dialog.winfo_children()))
            self.assertEqual(len([w for w in self.root.winfo_children() if isinstance(w, alarm.tk.Toplevel)]), 1)
            dialog.ok()
        self.automate_dialog(choose)
        self.assertEqual(alarm.MinuteDialog(self.root, 15).result, (8, 25))
        self.assertFalse(any(isinstance(w, alarm.tk.Toplevel) for w in self.root.winfo_children()))

    def test_title_and_button_github_icons(self):
        def check(dialog):
            self.assertEqual(dialog._github_icon.width(), 64)
            self.assertEqual(dialog._button_icon.width(), 16)
            dialog.cancel()
        self.automate_dialog(check)
        alarm.MinuteDialog(self.root)

    def test_hourly_reversion(self):
        def revert(dialog):
            dialog.use_hourly()
            dialog.minute.set('12')
            dialog.ok()
        self.automate_dialog(revert)
        self.assertEqual(alarm.MinuteDialog(self.root, (9, 15)).result, 12)

    def test_main_window_preview_and_change(self):
        with patch.dict(ns, HAS_TRAY=False, play_sound=Mock()):
            app = App(self.root, 15)
            self.root.update()
            self.assertEqual(app.lbl_rule.cget('text'), '매시 15분에 알림')
            with patch.dict(ns, datetime=Mock(now=lambda: datetime(2026, 10, 10, 11, 20))):
                with patch.object(alarm, 'MinuteDialog', return_value=Mock(result=(23, 59))):
                    app.change_minute()
                self.assertEqual(app.lbl_rule.cget('text'), '매일 23:59에 알림')
                self.assertEqual(app.next_alarm_time(), datetime(2026, 10, 10, 23, 59))
                app.fire()
                self.root.update()
                texts = [w.cget('text') for w in app.alert_window.winfo_children() if isinstance(w, alarm.tk.Label)]
                self.assertIn('매일 23:59에 설정한 알림입니다', texts)
                app.alert_window.destroy()
                app.alert_window = None
            with patch.object(alarm, 'MinuteDialog', return_value=Mock(result=0)):
                app.change_minute()
            self.assertEqual(app.lbl_rule.cget('text'), '매시 00분에 알림')
            self.assertIsNone(app.alarm_hour)


class ArchiveTests(unittest.TestCase):
    def test_preserved_dependencies_and_embedded_entrypoint(self):
        import rebuild
        original = next(Path('/workspace/attachments').glob('*/HourlyAlarm.exe')).read_bytes()
        changed = (ROOT / 'output/HourlyAlarm_TimeSettings.exe').read_bytes()
        _, _, before = rebuild.read_archive(original)
        _, _, after = rebuild.read_archive(changed)
        self.assertEqual(len(before), len(after))
        for old, new in zip(before, after):
            if old[0] != 'hourly_alarm':
                self.assertEqual(old, new)
            else:
                payload = zlib.decompress(new[1]) if new[3] else new[1]
                code = marshal.loads(payload)
                namespace = {'__name__': 'embedded_test'}
                exec(code, namespace)
                self.assertEqual(namespace['_original']['HourlyAlarm'].AUTO_CLOSE_SEC, 60)
                self.assertIn('MinuteDialog', namespace)


class IconResourceTests(unittest.TestCase):
    def test_executable_icons(self):
        import sys
        sys.path.insert(0, str(ROOT / 'build-libs'))
        import pefile
        from PIL import Image
        from io import BytesIO
        pe = pefile.PE(str(ROOT / 'output/HourlyAlarm_TimeSettings.exe'))
        icons = [entry for t in pe.DIRECTORY_ENTRY_RESOURCE.entries if t.id == 3 for entry in t.directory.entries]
        self.assertEqual(len(icons), 7)
        for entry in icons:
            data = entry.directory.entries[0].data.struct
            payload = pe.get_data(data.OffsetToData, data.Size)
            self.assertTrue(payload.startswith(b'\x89PNG'))
            Image.open(BytesIO(payload)).verify()


if __name__ == '__main__':
    unittest.main(verbosity=2)
